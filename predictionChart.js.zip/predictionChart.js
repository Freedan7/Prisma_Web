/**
 * Created by ravitejs_ganireddy on 29/03/2017.
 */
 
  //Cutoff constants
 var AKI_CUTOFF = 35;
 var ICU_CUTOFF = 35;
 var MV_CUTOFF = 13;
 var CV_CUTOFF = 7;
 var SEP_CUTOFF = 6;
 var MORT_CUTOFF = 5;
 //----------------

function wordwrap(text) {
    var lines=text.split(" ")
    return lines
}

function round(value, decimals) {
    return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
}

var dataset = [];

function generatechart(labels) {
    var colors = ['#027b02', '#027b02', '#027b02', '#027b02', '#027b02', '#027b02','#027b02'];
    for(i=0;i<labels.length;i++){
        dataset.push({});
        dataset[i].label = labels[i][0].label;
        dataset[i].radius = labels[i][0].outcome*100 + 20;
        dataset[i].riskNum = dataset[i].radius;
        dataset[i].start = 1 + 100 / labels.length * i;
        dataset[i].end = 100/labels.length * (i+1) - 1;
        dataset[i].color = colors[i];
        dataset[i].id = i;
        dataset[i].positive = labels[i][0].outcomeRankPositiveList;
        dataset[i].negative = labels[i][1].outcomeRankNegativeList;
        for(j=0;j<labels[i][0].outcomeRankPositiveList.length;j++){
           dataset[i].positive[j].isinclude = true;
        }
        for(j=0;j<labels[i][1].outcomeRankNegativeList.length;j++){
            dataset[i].negative[j].isinclude = true;
        }
        console.log(dataset[i].id + " = " + labels[i][0].label);
    }
          
    /*
    For testing purposes only
    
    dataset[0].radius = MORT_CUTOFF - 1;
    dataset[1].radius = SEP_CUTOFF - 1;
    dataset[2].radius = MV_CUTOFF - 1;
    dataset[3].radius = AKI_CUTOFF - 1;
    dataset[4].radius = CV_CUTOFF - 1;
    dataset[5].radius = ICU_CUTOFF - 1;
	*/
    
    //Scaling data sets
    	//Mortality rate---
    	if (dataset[0].radius >= MORT_CUTOFF + 20) {
    		console.log ("UGH");
    		dataset[0].radius = 70 + (dataset[0].radius - 20 - MORT_CUTOFF) / ((100 - MORT_CUTOFF)/50);
    	}
    	else {
    		dataset[0].radius = ((dataset[0].radius - 20) * ((120/MORT_CUTOFF)/2)) + 10;
    	}
    	//Severe Sepsis---
    	if (dataset[1].radius >= SEP_CUTOFF + 20) {
			dataset[1].radius = 70 + (dataset[1].radius - 20 - SEP_CUTOFF) / ((100 - SEP_CUTOFF)/50);
    	}
    	else {
    		dataset[1].radius = ((dataset[1].radius - 20) * ((120/SEP_CUTOFF)/2)) + 10;
    	}
    	//Mechanical Ventilation > 48hrs---
    	if (dataset[2].radius >= MV_CUTOFF + 20) {
			dataset[2].radius = 70 + (dataset[2].radius - 20 - MV_CUTOFF) / ((100 - MV_CUTOFF)/50);
    	}
    	else {
    		dataset[2].radius = ((dataset[2].radius - 20) * ((120/MV_CUTOFF)/2)) + 10;
    	}
    	//AKI first seven days---
    	if (dataset[3].radius >= AKI_CUTOFF + 20) {
    		dataset[3].radius = 70 + (dataset[3].radius - 20 - AKI_CUTOFF) / ((100 - AKI_CUTOFF)/50);
    	}
    	else {
    		dataset[3].radius = ((dataset[3].radius - 20) * ((120/AKI_CUTOFF)/2)) + 10;
    	}
    	//Cardiovascular Complications---
    	if (dataset[4].radius >= CV_CUTOFF + 20) {
			dataset[4].radius = 70 + (dataset[4].radius - 20 - CV_CUTOFF) / ((100 - CV_CUTOFF)/50);
    	}
    	else {
    		dataset[4].radius = ((dataset[4].radius - 20) * ((120/CV_CUTOFF)/2)) + 10;
    	}
    	//Admission to ICU > 48hrs---
    	if (dataset[5].radius >= ICU_CUTOFF + 20) {
    		dataset[5].radius = 70 + (dataset[5].radius - 20 - ICU_CUTOFF) / ((100 - ICU_CUTOFF)/50);
    	}
    	else {
    		dataset[5].radius = ((dataset[5].radius - 20) * ((120/ICU_CUTOFF)/2)) + 10;
    	}
    //---------------------------
    
    var width = 660,
        height = 550;
    var innerradius = 10;
    // var color = d3.scale.category20b();
    var cScale = d3.scale.linear().domain([0, 100]).range([0, 2 * Math.PI]);
    var radius = 130;
  	var svg = d3.selectAll('.predictionChart')
    	.append("svg")
  		.attr("preserveAspectRatio", "xMinYMin meet")
  		.attr("viewBox", "-250 -200 500 500")
  		.classed("svg-content", true);
        
    var arc = d3.svg.arc()
        .innerRadius(innerradius)
        .outerRadius(function(d){return d.radius + innerradius;})
        .startAngle(function(d){return cScale(d.start);})
        .endAngle(function(d){return cScale(d.end);});

    var path = svg.selectAll('g.slice')
        .data(dataset)
        .enter()
        .append('g')
        .attr('class','slice');

	//Why is it not updating??
    path.append('path')
        .attr('d', arc)
        /*
        .on('mouseover',
        function (d, i){
        	d3.selectAll('.riskPercent').style('opacity',
        		function(d) {
        			if (d.id == i) {
        				return 1;
        			}
        			else {
        				return 0;
        			}
        		}
        	);
        })
        .on('mouseout',
        function (d, i){
        	d3.selectAll('.riskPercent').style('opacity',
        		function(d) {
        			if (d.id == i) {
        				return 0;
        			}
        			else {
        				return 0;
        			}
        		}
        	);
        })
        */
        .style("stroke", "#d0d5d9")
        .style("stroke-width", 0.75)
        .style("fill-opacity", 0.65)
        .style("fill", function(d){
        						if(d.radius<70)return '#03e203';
        						else return '#ff0d00';
        					}
        				)
        .attr('id',function(d){return d.id});

	path.append('circle')
		.attr("transform",function(d){
            // d.outerRadius = 220 + 50;
            // d.innerRadius = 220 + 40;
            var c = arc.centroid(d),
                x = c[0], y = c[1];
            h = Math.sqrt(x*x + y*y);
            return "translate(" + (x/h * 180) +  ',' +
                (y/h * 180) +  ")";
        })
        .attr("color", "red")
        .attr("dy", ".5em");
	
    path.append('text')
        .attr("transform",function(d){
            // d.outerRadius = 220 + 50;
            // d.innerRadius = 220 + 40;
            var c = arc.centroid(d),
                x = c[0], y = c[1];
            h = Math.sqrt(x*x + y*y);
            return "translate(" + (x/h * 180) +  ',' +
                (y/h * 180) +  ")";
        })
        .attr("class", "label")
        .attr("text-anchor", "middle") //center the text on it's origin
        .attr("dy", ".35em")
        .style("fill", "#d0d5d9")
        .style("font", "bold 8px Arial")
        .each(function (d,i) {
            var arr = dataset[i].label.split(" ");
            var str = '';
            for (i = 0; i < arr.length; i++) {
                str = str + arr[i] + ' ';
                if(str.length>12 || i==arr.length-1) {
                    d3.select(this).append("tspan")
                        .text(str)
                        .attr("dy", i ? "1.2em" : 0)
                        .attr("x", 0)
                        .attr("text-anchor", "middle")
                        .attr("class", "tspan" + i);
                    str = '';
                }
            }
        });

	var svgText = path.append("svg:text")
		  .attr("transform",function(d){
				var c = arc.centroid(d),
					x = c[0], y = c[1];
				h = Math.sqrt(x*x + y*y);
				return "translate(" + (x/h * 60) +  ',' +
					(y/h * 60) +  ")";
			})
		  .attr("class", "riskPercent")
		  .attr("text-anchor", "middle")
		  .attr("font-size", "10")
		  .style("fill", "#fff")
		  .style("opacity", 0)
		  .text(function(d) {
            		d.pred = round(round(d.riskNum,2) -20,2);
            		return d.pred + "%";
		  });
		  
	svgText.append('tspan')
        		.text(function(d) {
        			return d.id;
        		})
        		.attr('dx', '-3em')
        		.attr('dy', '-1.2em')
		  

    var grid = d3.svg.area.radial()
        .radius(150);

// to add grid lines
    var sdat = [];
    sdat[0] = radius;

    addCircleAxes = function() {
        var circleAxes, i;

        svg.selectAll('.circle-ticks').remove();

        circleAxes = svg.selectAll('.circle-ticks')
            .data(sdat)
            .enter().append('svg:g')
            .attr("class", "circle-ticks");

        // radial tick lines
        circleAxes.append("svg:circle")
            .attr("r", String)
            .attr("class", "circle")
            .style("stroke", "#d0d5d9")
            .style("stroke-width", 1.5)
            .style("opacity", 0.75)
            .style("fill", "none");
    };

    addCircleAxes();

    buildTableRow = function (r1,r2,idx) {
        if(r1.length==0 && r2.length==0)
            return;
        if(r1[idx].isinclude==true)
            btn1 = 'btn-default';
        else
            btn1 = 'btn-danger';
        if(r2[idx].isinclude==true)
            btn2 = 'btn-default';
        else
            btn2 = 'btn-success';
        return '<tr>'
        + '<td>' + '<button type="button" class="btn ' + btn1 +' btn-click1 btn-block" id="' + idx +'">' + r1[idx].description +' <span class="icon-thumbs-up"></span> </button> </td>'
        + '<td>' + '<button type="button" class="btn ' + btn2 + ' btn-click2 btn-block" id="' + idx +'">' + r2[idx].description + '</button> </td>'
        + '</tr>';
    }

    $('.slice').click(function(event) {
        $('#modelWindow').modal('show');
        var i=event.target.id;
        $('.modal-title').html("Main factors contributing to patients risk " + dataset[i].label);
        // remove old rows and add new rows to table in the modal
        $('#prediction-table tr').not(function(){ return !!$(this).has('th').length; }).remove();
        for (j=0;j<3;j++) {
            $('#prediction-table').append(
                buildTableRow(dataset[i].positive,
                    dataset[i].negative,j)
                );
        }
        //Increasing risk buttons
        $('.btn-click1').click(function(event){
            if($(this).hasClass('btn-default')==true) {
                $(this).removeClass('btn-default').addClass('btn-danger');
                $(this).children('span').removeClass('icon-thumbs-up').addClass('icon-thumbs-down');
                dataset[i].positive[$(this).attr('id')].isinclude = false;
            }
            else {
                $(this).removeClass('btn-danger').addClass('btn-default');
                $(this).children('span').removeClass('icon-thumbs-down').addClass('icon-thumbs-up');
                dataset[i].positive[$(this).attr('id')].isinclude = true;
            }

        });
        //Decreasing risk buttons
        $('.btn-click2').click(function(event){
            if($(this).hasClass('btn-default')==true) {
                $(this).removeClass('btn-default').addClass('btn-success');
                dataset[i].negative[$(this).attr('id')].isinclude = false;
            }
            else {
                $(this).removeClass('btn-success').addClass('btn-default');
                dataset[i].negative[$(this).attr('id')].isinclude = true;
            }
        });
    });
    
    // $('#submit').click(function (event) {
    //     console.log(dataset);
    // });

}
